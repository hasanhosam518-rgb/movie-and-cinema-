"use client";

import { useState } from "react";
import Image from "next/image";
import type { NormalizedItem } from "@/lib/types";

type Category = "any" | "movie" | "game";

export default function Home() {
  const [category, setCategory] = useState<Category>("any");
  const [time, setTime] = useState<string>("");
  const [genre, setGenre] = useState<string>("");
  const [results, setResults] = useState<NormalizedItem[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function getRecommendations() {
    setLoading(true);
    setError(null);
    setResults(null);
    const params = new URLSearchParams();
    if (category !== "any") params.set("category", category);
    if (time) params.set("time", time);
    if (genre) params.set("genre", genre);

    try {
      const res = await fetch(`/api/recommend?${params.toString()}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Something went wrong");
      setResults(data.results.map((r: { item: NormalizedItem }) => r.item));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-neutral-950 text-neutral-100 px-6 py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-semibold mb-2">Entertainment OS</h1>
        <p className="text-neutral-400 mb-8">What do you want to enjoy tonight?</p>

        <div className="flex gap-3 mb-6">
          {(["any", "movie", "game"] as Category[]).map((c) => (
            <button
              key={c}
              onClick={() => setCategory(c)}
              className={`px-4 py-2 rounded-full border text-sm ${
                category === c
                  ? "bg-white text-black border-white"
                  : "border-neutral-700 text-neutral-300"
              }`}
            >
              {c === "any" ? "Anything" : c === "movie" ? "Watch" : "Play"}
            </button>
          ))}
        </div>

        <div className="flex flex-wrap gap-3 mb-6">
          <input
            type="number"
            placeholder="Minutes you have (optional)"
            value={time}
            onChange={(e) => setTime(e.target.value)}
            className="bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm w-56"
          />
          <input
            type="text"
            placeholder="Genre hint, e.g. thriller (optional)"
            value={genre}
            onChange={(e) => setGenre(e.target.value)}
            className="bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-sm w-56"
          />
        </div>

        <button
          onClick={getRecommendations}
          disabled={loading}
          className="bg-white text-black rounded-lg px-5 py-2 font-medium disabled:opacity-50"
        >
          {loading ? "Finding something…" : "Recommend something"}
        </button>

        {error && (
          <p className="mt-6 text-red-400 text-sm">
            {error} — check that TMDB_API_KEY / RAWG_API_KEY are set in .env.local.
          </p>
        )}

        {results && (
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-3 gap-6">
            {results.map((item) => (
              <div key={item.id} className="space-y-2">
                {item.posterUrl ? (
                  <Image
                    src={item.posterUrl}
                    alt={item.title}
                    width={200}
                    height={300}
                    className="rounded-lg w-full h-auto object-cover"
                  />
                ) : (
                  <div className="aspect-[2/3] bg-neutral-800 rounded-lg" />
                )}
                <p className="text-sm font-medium leading-tight">{item.title}</p>
                <p className="text-xs text-neutral-500">
                  {item.rating != null ? `${item.rating.toFixed(1)}/10` : "No rating"} ·{" "}
                  <a
                    href={item.source.attributionUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    via {item.source.provider === "tmdb" ? "TMDB" : "RAWG"}
                  </a>
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
