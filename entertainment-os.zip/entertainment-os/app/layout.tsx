import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Entertainment OS — What should you watch, play, or listen to?",
  description:
    "AI-assisted recommendations for movies, games, and music, matched to your mood and time.",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col font-sans">{children}</body>
    </html>
  );
}
