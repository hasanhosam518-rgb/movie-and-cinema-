import { NextRequest, NextResponse } from "next/server";
import { fetchPopularMovies } from "@/lib/providers/tmdb";
import { fetchPopularGames } from "@/lib/providers/rawg";
import { rankItems } from "@/lib/recommend";
import { RecommendationQuery } from "@/lib/types";

export async function GET(req: NextRequest) {
  const params = req.nextUrl.searchParams;
  const query: RecommendationQuery = {
    category: (params.get("category") as RecommendationQuery["category"]) ?? "any",
    timeAvailableMinutes: params.get("time") ? Number(params.get("time")) : undefined,
    genreHint: params.get("genre") ?? undefined,
  };

  try {
    const [movies, games] = await Promise.all([
      query.category === "game" ? Promise.resolve([]) : fetchPopularMovies(),
      query.category === "movie" || query.category === "tv"
        ? Promise.resolve([])
        : fetchPopularGames(),
    ]);

    const ranked = rankItems([...movies, ...games], query).slice(0, 12);

    return NextResponse.json({ results: ranked });
  } catch (err) {
    // Never fabricate results on API failure — surface the real error instead.
    const message = err instanceof Error ? err.message : "Unknown error";
    return NextResponse.json({ error: message }, { status: 502 });
  }
}
