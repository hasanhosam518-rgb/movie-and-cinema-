import { NormalizedItem } from "../types";

const TMDB_BASE = "https://api.themoviedb.org/3";
const IMG_BASE = "https://image.tmdb.org/t/p/w342";

function apiKey(): string {
  const key = process.env.TMDB_API_KEY;
  if (!key) {
    throw new Error(
      "TMDB_API_KEY is not set. Add it to .env.local (see README) before calling this provider."
    );
  }
  return key;
}

interface TmdbGenre {
  id: number;
  name: string;
}

interface TmdbMovieResult {
  id: number;
  title: string;
  overview: string;
  vote_average: number;
  release_date: string | null;
  poster_path: string | null;
  genre_ids: number[];
  runtime?: number;
}

let genreCache: Record<number, string> | null = null;

async function getGenreMap(): Promise<Record<number, string>> {
  if (genreCache) return genreCache;
  const res = await fetch(
    `${TMDB_BASE}/genre/movie/list?api_key=${apiKey()}&language=en-US`,
    { next: { revalidate: 60 * 60 * 24 } } // cache 24h — respect TMDB rate limits
  );
  if (!res.ok) throw new Error(`TMDB genre fetch failed: ${res.status}`);
  const data = await res.json();
  const map: Record<number, string> = {};
  (data.genres as TmdbGenre[]).forEach((g) => (map[g.id] = g.name));
  genreCache = map;
  return map;
}

function normalizeMovie(m: TmdbMovieResult, genreMap: Record<number, string>): NormalizedItem {
  return {
    id: `tmdb-movie-${m.id}`,
    category: "movie",
    title: m.title,
    overview: m.overview,
    rating: m.vote_average ?? null,
    releaseDate: m.release_date || null,
    posterUrl: m.poster_path ? `${IMG_BASE}${m.poster_path}` : null,
    genres: m.genre_ids?.map((id) => genreMap[id]).filter(Boolean) ?? [],
    runtimeMinutes: m.runtime ?? null,
    source: {
      provider: "tmdb",
      attributionUrl: "https://www.themoviedb.org/",
    },
  };
}

/**
 * Fetch currently popular movies from TMDB and normalize them.
 * This is the only exported entry point — callers never see raw TMDB shapes.
 */
export async function fetchPopularMovies(page = 1): Promise<NormalizedItem[]> {
  const [genreMap, res] = await Promise.all([
    getGenreMap(),
    fetch(`${TMDB_BASE}/movie/popular?api_key=${apiKey()}&language=en-US&page=${page}`, {
      next: { revalidate: 60 * 60 * 6 }, // 6h cache — avoid hammering the API
    }),
  ]);
  if (!res.ok) throw new Error(`TMDB popular movies fetch failed: ${res.status}`);
  const data = await res.json();
  return (data.results as TmdbMovieResult[]).map((m) => normalizeMovie(m, genreMap));
}

export async function searchMovies(query: string): Promise<NormalizedItem[]> {
  const genreMap = await getGenreMap();
  const res = await fetch(
    `${TMDB_BASE}/search/movie?api_key=${apiKey()}&language=en-US&query=${encodeURIComponent(
      query
    )}`,
    { next: { revalidate: 60 * 60 } }
  );
  if (!res.ok) throw new Error(`TMDB search failed: ${res.status}`);
  const data = await res.json();
  return (data.results as TmdbMovieResult[]).map((m) => normalizeMovie(m, genreMap));
}
