import { NormalizedItem } from "../types";

const RAWG_BASE = "https://api.rawg.io/api";

function apiKey(): string {
  const key = process.env.RAWG_API_KEY;
  if (!key) {
    throw new Error(
      "RAWG_API_KEY is not set. Add it to .env.local (see README) before calling this provider."
    );
  }
  return key;
}

interface RawgGame {
  id: number;
  name: string;
  description_raw?: string;
  rating: number; // 0-5 scale
  released: string | null;
  background_image: string | null;
  genres: { name: string }[];
  playtime: number; // average hours, not minutes — not the same as movie runtime
}

function normalizeGame(g: RawgGame): NormalizedItem {
  return {
    id: `rawg-${g.id}`,
    category: "game",
    title: g.name,
    overview: g.description_raw ?? "",
    rating: g.rating != null ? g.rating * 2 : null, // normalize RAWG's 0-5 to 0-10
    releaseDate: g.released,
    posterUrl: g.background_image,
    genres: g.genres?.map((gn) => gn.name) ?? [],
    runtimeMinutes: null, // RAWG gives average playtime in hours, not a fixed runtime — not comparable to movie runtime, so left null intentionally
    source: {
      provider: "rawg",
      // RAWG's terms require attribution + a live backlink on any page using this data
      attributionUrl: "https://rawg.io/",
    },
  };
}

/**
 * Fetch currently popular games from RAWG and normalize them.
 */
export async function fetchPopularGames(page = 1): Promise<NormalizedItem[]> {
  const res = await fetch(
    `${RAWG_BASE}/games?key=${apiKey()}&ordering=-added&page=${page}&page_size=20`,
    {
      headers: { "User-Agent": "EntertainmentOS/0.1 (MVP)" },
      next: { revalidate: 60 * 60 * 6 }, // 6h cache — RAWG free tier is 20k req/month
    }
  );
  if (!res.ok) throw new Error(`RAWG popular games fetch failed: ${res.status}`);
  const data = await res.json();
  return (data.results as RawgGame[]).map(normalizeGame);
}

export async function searchGames(query: string): Promise<NormalizedItem[]> {
  const res = await fetch(
    `${RAWG_BASE}/games?key=${apiKey()}&search=${encodeURIComponent(query)}&page_size=20`,
    { headers: { "User-Agent": "EntertainmentOS/0.1 (MVP)" }, next: { revalidate: 60 * 60 } }
  );
  if (!res.ok) throw new Error(`RAWG search failed: ${res.status}`);
  const data = await res.json();
  return (data.results as RawgGame[]).map(normalizeGame);
}
