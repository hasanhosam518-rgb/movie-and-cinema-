import { NormalizedItem, RecommendationQuery } from "./types";

/**
 * MVP scoring: deterministic and explainable, no AI call required.
 * This matters for cost control (rule #26 in the brief) — most filtering/sorting
 * doesn't need a model call at all. Swap in an LLM later only for free-text intent
 * parsing, not for scoring itself.
 */
export function scoreItem(item: NormalizedItem, query: RecommendationQuery): number {
  let score = 0;
  const reasons: string[] = [];

  // Base: popularity/quality signal from the provider's own rating
  if (item.rating != null) score += item.rating * 5;

  // Category match
  if (query.category && query.category !== "any" && item.category === query.category) {
    score += 20;
  }

  // Time budget: only meaningful for movies/TV with a known runtime
  if (query.timeAvailableMinutes && item.runtimeMinutes) {
    const diff = Math.abs(item.runtimeMinutes - query.timeAvailableMinutes);
    if (diff <= 15) score += 15;
    else if (diff <= 30) score += 8;
  }

  // Genre hint (simple substring match against normalized genre list)
  if (query.genreHint) {
    const hint = query.genreHint.toLowerCase();
    if (item.genres.some((g) => g.toLowerCase().includes(hint))) {
      score += 15;
      reasons.push(`matches genre "${query.genreHint}"`);
    }
  }

  return score;
}

export interface ScoredItem {
  item: NormalizedItem;
  score: number;
}

export function rankItems(items: NormalizedItem[], query: RecommendationQuery): ScoredItem[] {
  return items
    .map((item) => ({ item, score: scoreItem(item, query) }))
    .sort((a, b) => b.score - a.score);
}
