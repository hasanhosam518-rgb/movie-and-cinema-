// Shared normalized shape every provider (TMDB, RAWG, ...) maps into.
// This is the abstraction layer: the rest of the app never talks to a
// provider's raw response shape directly, only to this.

export type MediaCategory = "movie" | "tv" | "game";

export interface NormalizedItem {
  id: string;              // "tmdb-movie-27205" / "rawg-3498"
  category: MediaCategory;
  title: string;
  overview: string;
  rating: number | null;   // 0-10 normalized
  releaseDate: string | null; // ISO date, or null if unknown
  posterUrl: string | null;
  genres: string[];
  runtimeMinutes: number | null; // null for games / unknown
  source: {
    provider: "tmdb" | "rawg";
    attributionUrl: string; // required by both providers' terms
  };
}

export interface RecommendationQuery {
  mood?: string;
  timeAvailableMinutes?: number;
  category?: MediaCategory | "any";
  genreHint?: string;
  freeText?: string; // "give me something exciting but not violent"
}
