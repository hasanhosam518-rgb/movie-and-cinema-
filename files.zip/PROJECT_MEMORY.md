# PROJECT_MEMORY.md — Entertainment OS

## Mission
Cross-media "what should I watch/play tonight" discovery + AI recommendation tool.
Positioning: "One intelligent place to discover what to watch, play and listen to."

## Business model (decided, Phase 0 — 2026-08-31)
- MVP monetizes with **nothing fake**: no affiliate links until real partnerships exist.
- Core wedge: decision fatigue, not another catalog/database site.
- Music is a secondary module — no viable free affiliate/commercial path found yet, deprioritized vs movies/games.
- Real revenue path (post-traffic): apply to actual affiliate programs (streaming services, CDKeys/Fanatical-style game resellers, display ads via a real ad network) — not before there's traffic to justify approval.

## Data providers (verified 2026-08-31)
- **Movies/TV**: TMDB API. Free non-commercial; **$149/mo required once monetized**, needs attribution. `watch/providers` endpoint gives limited legal-availability data.
- **Games**: RAWG API. Free under 100K MAU / 500K pageviews/mo, needs attribution + backlink, cache aggressively (20K req/mo free cap).
- **Music**: Spotify Web API (OAuth, previews only, no affiliate) or Last.fm — deprioritized.
- **Streaming availability (JustWatch-grade)**: enterprise/paid only — not available at MVP. Known gap, not solved yet.

## Architecture (planned, not yet built)
Data Provider → Normalization Layer → DB → Recommendation Engine → Website
No app framework, hosting, or repo has been chosen yet — BLOCKED on user decision.

## Current phase
Phase 0 (research) — complete.
Phase 1 (architecture/stack decision) — awaiting user input.

## Completed
- Market/API research for movies, games, music data sources.
- Business model decision (decision-fatigue wedge, no fake monetization at MVP).

## Blocked by external requirement
- Tech stack / hosting choice (needs user decision).
- TMDB API key (user must create free account + request key).
- RAWG API key (user must create free account).
- Domain name / deployment target — not yet chosen.

## Next exact action
Ask user: framework preference (Next.js recommended, but confirm), hosting target
(Vercel/Render — user has Render + Vercel + Netlify connectors available), and whether
they already hold TMDB/RAWG keys. Then scaffold Phase 2 (data abstraction layer) for real,
with working code against live TMDB/RAWG responses — not mocked.

## Decisions log
- 2026-08-31: Chose "decision-fatigue / tonight-picker" over broad IMDb-style catalog — evidence: free data APIs only cover metadata, not licensing/availability at scale, so a catalog play needs paid APIs the user doesn't have yet; a thin recommendation layer doesn't.
